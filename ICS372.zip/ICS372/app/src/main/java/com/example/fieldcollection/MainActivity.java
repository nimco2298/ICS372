package com.example.fieldcollection;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_addAReading = findViewById(R.id.btn_addAReading);
        Button btn_startDataCollection = findViewById(R.id.btn_startDataCollection);
        Button btn_endDataCollection = findViewById(R.id.btn_endDataCollection);
        Button btn_invalidateSite = findViewById(R.id.btn_invalidateSite);
        Button btn_import = findViewById(R.id.btn_import);
        Button btn_export = findViewById(R.id.btn_export);
        Button btn_viewDataLog = findViewById(R.id.btn_viewDataLog);


        btn_addAReading.setOnClickListener(this);
        btn_startDataCollection.setOnClickListener(this);
        btn_endDataCollection.setOnClickListener(this);
        btn_invalidateSite.setOnClickListener(this);
        btn_import.setOnClickListener(this);
        btn_export.setOnClickListener(this);
        btn_viewDataLog.setOnClickListener(this);



    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_addAReading:
                openaddAReading();
                break;
            case R.id.btn_startDataCollection:
                openstartDataCollection();
                break;
            case R.id.btn_endDataCollection:
                openendDataCollection();
                break;
            case R.id.btn_invalidateSite:
                openinvalidateSite();
                break;
            case R.id.btn_import:
                openImportFile();
                break;
            case R.id.btn_export:
                openExportFile();
                break;
            case R.id.btn_viewDataLog:
                openViewDataLog();
                break;
        }
    }


    public void openaddAReading() {
        Intent readingIntent = new Intent(this, AddAReading.class);
        startActivity(readingIntent);
    }
    public void openstartDataCollection() {
        Intent startDataIntent = new Intent(this, StartDataCollection.class);
        startActivity(startDataIntent);
    }
    public void openendDataCollection() {
        Intent endDataIntent = new Intent(this, EndDataCollection.class);
        startActivity(endDataIntent);
    }

    public void openinvalidateSite() {
        Intent invalidateIntent = new Intent(this, InvalidateSite.class);
        startActivity(invalidateIntent);
    }

    public void openImportFile() {
        Intent importIntent = new Intent(this, Import.class);
        startActivity(importIntent);
    }
    public void openExportFile() {
        Intent exportIntent = new Intent(this, Export.class);
        startActivity(exportIntent);
    }
    public void openViewDataLog() {
        Intent datalogItent = new Intent(this, ViewDataLog.class);
        startActivity(datalogItent);
    }
}
